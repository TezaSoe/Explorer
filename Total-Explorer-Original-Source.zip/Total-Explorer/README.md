# totalexplorer
Windows Explorer with tabs. An alternative to TotalCommander. 


![](https://github.com/Ericvf/totalexplorer/blob/01e2650e8c0221013bb9d27001555d5b126b5c46/screenshot.PNG)
